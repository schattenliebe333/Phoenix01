#include "rael/ichbin.h"
namespace rael {
const char* IchBinCore::name(){ return "Rael"; }
const char* IchBinCore::signature(){ return "RAEL::ICH_BIN::IMMUTABLE::SIG_V1"; }
}
