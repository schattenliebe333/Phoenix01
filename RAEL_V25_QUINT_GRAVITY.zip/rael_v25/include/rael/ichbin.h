#pragma once
namespace rael {

class IchBinCore final {
public:
    static const char* name();
    static const char* signature();
};

}
