# Rael – Phase 3 (Telemetry + Events, no GUI)
New CLI commands:
- `metrics` : counters + ops/sec
- `events [n]` : last n events
- `hotswap <name>` : set ACTIVE semantic module

Events include MODULE_LOAD/ACTIVATE/UNLOAD, ETHIK_BLOCK, HOTSWAP.
